 

<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-4 py-8">
    <h1 class="text-3xl font-bold text-gray-800 mb-6">Laporan Restoran</h1>

    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div class="bg-white p-6 rounded-lg shadow-md">
            <h3 class="text-lg font-semibold text-gray-500">Total Omzet</h3>
            <p class="text-3xl font-bold text-green-600 mt-2">Rp <?php echo e(number_format($totalOmzet, 0, ',', '.')); ?></p>
            <p class="text-sm text-gray-400">Dari pesanan yang selesai</p>
        </div>
        <div class="bg-white p-6 rounded-lg shadow-md">
            <h3 class="text-lg font-semibold text-gray-500">Total Transaksi</h3>
            <p class="text-3xl font-bold text-blue-600 mt-2"><?php echo e($totalTransaksi); ?></p>
            <p class="text-sm text-gray-400">Jumlah pesanan berhasil</p>
        </div>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
        
        <div>
            <div class="bg-white p-6 rounded-lg shadow-md mb-8">
                <h3 class="text-xl font-bold text-gray-700 mb-4">Member Teraktif (Top 5)</h3>
                <ul class="space-y-3">
                    <?php $__empty_1 = true; $__currentLoopData = $memberTeraktif; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <li class="flex justify-between items-center">
                            <span class="text-gray-600"><?php echo e($member->customer->name ?? 'Customer Dihapus'); ?></span>
                            <span class="font-semibold text-blue-500 bg-blue-100 px-2 py-1 rounded"><?php echo e($member->total_orders); ?> Pesanan</span>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="text-gray-500">Belum ada data pesanan.</p>
                    <?php endif; ?>
                </ul>
            </div>

            <div class="bg-white p-6 rounded-lg shadow-md">
                <h3 class="text-xl font-bold text-gray-700 mb-4">Member dengan Pembelian Terbanyak (Top 5)</h3>
                <ul class="space-y-3">
                    <?php $__empty_1 = true; $__currentLoopData = $memberTopSpender; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <li class="flex justify-between items-center">
                            <span class="text-gray-600"><?php echo e($member->customer->name ?? 'Customer Dihapus'); ?></span>
                            <span class="font-semibold text-green-500 bg-green-100 px-2 py-1 rounded">Rp <?php echo e(number_format($member->total_spent, 0, ',', '.')); ?></span>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="text-gray-500">Belum ada data pesanan.</p>
                    <?php endif; ?>
                </ul>
            </div>
        </div>

        <div>
            <div class="bg-white p-6 rounded-lg shadow-md mb-8">
                <h3 class="text-xl font-bold text-gray-700 mb-4">Produk Terlaris (Top 5)</h3>
                <ul class="space-y-3">
                    <?php $__empty_1 = true; $__currentLoopData = $produkTerlaris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <li class="flex justify-between items-center">
                            <span class="text-gray-600"><?php echo e($menu->name); ?></span>
                            <span class="font-semibold text-purple-500 bg-purple-100 px-2 py-1 rounded"><?php echo e($menu->sales_count); ?>x terjual</span>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="text-gray-500">Belum ada produk yang terjual.</p>
                    <?php endif; ?>
                </ul>
            </div>

            <div class="bg-white p-6 rounded-lg shadow-md">
                <h3 class="text-xl font-bold text-gray-700 mb-4">Produk Perlu Perhatian (Paling Sedikit Terjual)</h3>
                <ul class="space-y-3">
                     <?php $__empty_1 = true; $__currentLoopData = $produkPerluEndorse; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <li class="flex justify-between items-center">
                            <span class="text-gray-600"><?php echo e($menu->name); ?></span>
                            <span class="font-semibold text-red-500 bg-red-100 px-2 py-1 rounded"><?php echo e($menu->sales_count); ?>x terjual</span>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="text-gray-500">Semua produk memiliki penjualan.</p>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ASUS ROG\Documents\GitHub\WFP_Food_Order\resources\views/restaurant/report.blade.php ENDPATH**/ ?>