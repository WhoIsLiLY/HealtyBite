<?php if(auth('customer')->check()): ?>

<?php elseif(auth('admin')->check()): ?>
    <footer class="bg-gray-700 text-white p-4 text-center">
        <p>&copy; 2025 Healthy Food Ordering System. All rights reserved.</p>
    </footer>
<?php endif; ?>
<?php /**PATH C:\Users\ASUS ROG\Documents\GitHub\WFP_Food_Order\resources\views/partials/footer.blade.php ENDPATH**/ ?>