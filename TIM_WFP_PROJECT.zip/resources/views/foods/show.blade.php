<p>Name: {{ $food->name }}</p>
<p>Price: {{ $food->price }}</p>
<p>Category: {{ $food->category->name }}</p>