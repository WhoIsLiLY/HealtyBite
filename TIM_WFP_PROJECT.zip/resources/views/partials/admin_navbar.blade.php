<nav class="bg-gray-900 p-4">
    <div class="flex justify-between items-center">
        <a href="/admin/dashboard" class="text-white font-bold text-xl">Admin Panel</a>
        <div>
            <a href="/admin/menu" class="text-white mx-4">Menu Management</a>
            <a href="/admin/orders" class="text-white">Order History</a>
        </div>
    </div>
</nav>
