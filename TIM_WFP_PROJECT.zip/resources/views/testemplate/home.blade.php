@extends('testemplate.base')

@section("title", "home page")

@section("content")
    <h1>Selamat datang di toko online</h1>
    <p>Promo hari ini</p>
    <ul>
        <li>mi instan</li>
        <li>micin</li>
        <li>ketupat</li>
        <li>sarung</li>
    </ul>
@endsection