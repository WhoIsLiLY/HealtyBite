@extends('testemplate.base')

@section("title", "cari barang")

@section("content")
    <h1>Ups barang tidak ditemukan</h1>
@endsection