<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('restaurants', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('location');
            $table->text('description')->nullable(); 
            $table->string('email')->unique();
            $table->string('password'); 
            $table->string('phone_number');
            $table->string('image', 255)->nullable();
            $table->foreignId('restaurant_categories_id')->nullable()->constrained()->onDelete('cascade');
            $table->timestamps();
            $table->string('restaurant_image')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('restaurants');
    }
};
